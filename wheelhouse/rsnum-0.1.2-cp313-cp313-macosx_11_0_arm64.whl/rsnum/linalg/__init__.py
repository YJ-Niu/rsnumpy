"""rsnum.linalg - Linear algebra module."""

import rsnum._core as _core


def _ensure(x):
    from ..__init__ import ndarray
    if isinstance(x, (list, tuple)):
        return _core.ndarray(x)
    elif isinstance(x, ndarray):
        return x._array
    return x


class linalg_module:
    """线性代数模块"""
    
    @staticmethod
    def dot(a, b):
        """计算两个数组的点积。
        
        参数:
            a: 第一个数组。
            b: 第二个数组。
        
        返回:
            标量或 ndarray: 点积结果。
        """
        from ..__init__ import ndarray
        a_arr = ndarray(a)
        b_arr = ndarray(b)
        a_data = a_arr.tolist()
        b_data = b_arr.tolist()
        
        a_is_1d = not isinstance(a_data[0], list)
        b_is_1d = not isinstance(b_data[0], list)
        
        if a_is_1d and b_is_1d:
            return sum(x * y for x, y in zip(a_data, b_data))
        
        if a_is_1d:
            rows_b = len(b_data)
            cols_b = len(b_data[0]) if isinstance(b_data[0], list) else 1
            if cols_b == 1:
                return sum(a_data[i] * b_data[i][0] for i in range(len(a_data)))
            result = [sum(a_data[k] * b_data[k][j] for k in range(len(a_data))) for j in range(cols_b)]
            return ndarray(result)
        
        if b_is_1d:
            rows_a = len(a_data)
            return [sum(a_data[i][k] * b_data[k] for k in range(len(b_data))) for i in range(rows_a)]
        
        rows_a = len(a_data)
        cols_a = len(a_data[0])
        rows_b = len(b_data)
        cols_b = len(b_data[0])
        
        if cols_a != rows_b:
            raise ValueError(f"Shape mismatch: {cols_a} != {rows_b}")
        
        result = [[sum(a_data[i][k] * b_data[k][j] for k in range(cols_a)) for j in range(cols_b)] for i in range(rows_a)]
        return ndarray(result)
    
    @staticmethod
    def matmul(a, b):
        """计算两个数组的矩阵乘积。"""
        from ..__init__ import ndarray
        a_arr = ndarray(a)
        b_arr = ndarray(b)
        a_data = a_arr.tolist()
        b_data = b_arr.tolist()
        
        rows_a = len(a_data)
        cols_a = len(a_data[0]) if isinstance(a_data[0], list) else 1
        rows_b = len(b_data)
        cols_b = len(b_data[0]) if isinstance(b_data[0], list) else 1
        
        if cols_a != rows_b:
            raise ValueError(f"Shape mismatch: {cols_a} != {rows_b}")
        
        if cols_a == 1 and rows_b == 1:
            result = [[sum(a_data[i][0] * b_data[0][j] for _ in range(1)) for j in range(cols_b)] for i in range(rows_a)]
        else:
            result = [[sum(a_data[i][k] * b_data[k][j] for k in range(cols_a)) for j in range(cols_b)] for i in range(rows_a)]
        
        return ndarray(result)
    
    @staticmethod
    def inv(a):
        """计算矩阵的逆。"""
        from ..__init__ import ndarray, _wrap_result
        return _wrap_result(_core.linalg.inv(_ensure(a)))
    
    @staticmethod
    def det(a):
        """计算矩阵的行列式。"""
        return _core.linalg.det(_ensure(a))
    
    @staticmethod
    def norm(x, ord=None, axis=None):
        """计算矩阵或向量的范数。"""
        return _core.linalg.norm(_ensure(x), ord, axis)
    
    @staticmethod
    def solve(a, b):
        """求解线性方程组。"""
        from ..__init__ import ndarray, _wrap_result
        return _wrap_result(_core.linalg.solve(_ensure(a), _ensure(b)))
    
    @staticmethod
    def eig(a):
        """计算矩阵的特征值和特征向量。"""
        return _core.linalg.eig(_ensure(a))
    
    @staticmethod
    def eigvals(a):
        """计算矩阵的特征值。"""
        return _core.linalg.eigvals(_ensure(a))
    
    @staticmethod
    def svd(a):
        """计算奇异值分解。"""
        return _core.linalg.svd(_ensure(a))
    
    @staticmethod
    def qr(a):
        """计算 QR 分解。"""
        return _core.linalg.qr(_ensure(a))
    
    @staticmethod
    def cholesky(a):
        """计算 Cholesky 分解。"""
        from ..__init__ import ndarray, _wrap_result
        return _wrap_result(_core.linalg.cholesky(_ensure(a)))
    
    @staticmethod
    def matrix_power(a, n):
        """计算矩阵的幂。"""
        from ..__init__ import ndarray, _wrap_result
        return _wrap_result(_core.linalg.matrix_power(_ensure(a), n))
    
    @staticmethod
    def pinv(a):
        """计算矩阵的伪逆。"""
        from ..__init__ import ndarray, _wrap_result
        return _wrap_result(_core.linalg.pinv(_ensure(a)))
    
    @staticmethod
    def trace(a):
        """计算矩阵的迹。"""
        return _core.linalg.trace(_ensure(a))
    
    @staticmethod
    def diagonal(a):
        """返回矩阵的对角线元素。"""
        from ..__init__ import ndarray, _wrap_result
        return _wrap_result(_core.linalg.diagonal(_ensure(a)))
    
    @staticmethod
    def svdvals(a):
        """计算奇异值。"""
        from ..__init__ import ndarray, _wrap_result
        return _wrap_result(_core.linalg.svdvals(_ensure(a)))
    
    @staticmethod
    def eigh(a):
        """计算 Hermitian 或对称矩阵的特征值和特征向量。"""
        return _core.linalg.eigh(_ensure(a))
    
    @staticmethod
    def solve_banded(lower, upper, ab, b):
        """求解带状线性方程组。"""
        from ..__init__ import ndarray, _wrap_result
        return _wrap_result(_core.linalg.solve_banded(lower, upper, _ensure(ab), _ensure(b)))